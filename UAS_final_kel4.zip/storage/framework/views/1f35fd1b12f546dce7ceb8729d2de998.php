<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mencetak Bilangan Genap</title>
</head>
<body>
    <h2>Mencetak Bilangan Genap</h2>
    <form action="/muncul" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" name="numbers" placeholder="1,2,3,4,5,6" required>
        <button type="submit">Submit</button>
    </form>
    <?php if(isset($result)): ?>
        <p>Hasil: <?php echo e($result); ?></p>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\Users\ASUS\UTS PW J0404231121 REINO AIMAR RAFIF\resources\views/genap.blade.php ENDPATH**/ ?>