<!DOCTYPE html>
<html>
<head>
    <title>Manage Users</title>
</head>
<body>
    <h2>Users from Firebase</h2>

    <?php if(session('success')): ?>
        <p style="color:green"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <table border="1" cellpadding="10">
        <thead>
            <tr>
                <th>UID</th>
                <th>Email</th>
                <th>Name</th>
                <th>Role</th>
                <th>Edit</th>
            </tr>
        </thead>
        <tbody>
        <?php if($users): ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uid => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($uid); ?></td>
                    <td><?php echo e($user['email'] ?? '-'); ?></td>
                    <td><?php echo e($user['name'] ?? '-'); ?></td>
                    <td>
                        <?php echo e($user['role'] ?? '-'); ?>

                    </td>
                    <td>
                        <!-- Pindahkan form update role ke kolom Edit -->
                        <form method="POST" action="<?php echo e(url('/update-role/' . $uid)); ?>">
                            <?php echo csrf_field(); ?>
                            <select name="role">
                                <option value="user" <?php echo e(($user['role'] ?? '') === 'user' ? 'selected' : ''); ?>>User</option>
                                <option value="admin" <?php echo e(($user['role'] ?? '') === 'admin' ? 'selected' : ''); ?>>Admin</option>
                            </select>
                            <button type="submit">Update</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr><td colspan="5">No user found</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\ASUS\UAS\resources\views/role.blade.php ENDPATH**/ ?>