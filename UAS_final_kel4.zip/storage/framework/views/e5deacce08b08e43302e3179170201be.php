<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Memeriksa Bilangan Bulat / Desimal</title>
</head>
<body>
    <h2>Memeriksa Bilangan Bulat / Desimal</h2>
    <form action="/cek-bilangan" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" name="angka" placeholder="pakai (.) untuk desimal" required>
        <button type="submit">Submit</button>
    </form>

    <?php if(isset($hasil)): ?>
        <p>Hasil: <?php echo e($hasil); ?></p>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\Users\ASUS\penilaian-app\resources\views/bilangan.blade.php ENDPATH**/ ?>